package Game;
import Field.FieldCreator;
import org.academiadecodigo.simplegraphics.graphics.Color;
import org.academiadecodigo.simplegraphics.graphics.Rectangle;
import org.academiadecodigo.simplegraphics.graphics.Text;
import org.academiadecodigo.simplegraphics.pictures.Picture;
public class Sandbox {
    public static void main(String[] args) {
        FieldCreator    field = new FieldCreator();
    }
}
