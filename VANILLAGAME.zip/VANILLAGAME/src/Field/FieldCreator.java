package Field;
//GIVES US ACCESS TO THE GAME SCREEN
//import Game.GamePanel;
import org.academiadecodigo.simplegraphics.graphics.Color;
import org.academiadecodigo.simplegraphics.graphics.Rectangle;
import org.academiadecodigo.simplegraphics.graphics.Text;
import Character.Player;

public class FieldCreator {
    //ISTANCIATING THE GAME PANEL ALLOWS US TO
    // READ THE MAP AND LATER DRAW IT ON THE SCREEN(ignore the red)
    //GamePanel gp;
    //THE ARRAY THAT WILL CONTAIN ALL THE DIFERENT TYPES OF CELLS(SOLID,OR NOT);
    public Cell[] cell;
    //TWO DIMENSIONAL ARRAY THAT HOLDS THE COORDINATES OF EACH CELL
    public int MapCellNum[][];
    //FIELD CREATOR CONSTRUCTOR
    public FieldCreator(){
        //this.gp = gp;

        Rectangle rectangle = new Rectangle(10, 10, 800, 500);
        rectangle.setColor(Color.BLACK);
        rectangle.fill();


        Dialoge d2 = new Dialoge();
        d2.init();





        Text text = new Text(350, 20, "EX-MACHINA");
        text.draw();

        //Player player = new Player("resources/poo.png");
        //poo.init();

       ;

    }
    //METHOD WHERE WE WILL ACTUALLY IMPORT THE CELL IMAGES FROM THE LIBRARY
    public void getCellImage(){

    }
    //METHOD RECEIVES THE MAP FILE AND USES A SCANNER TO READ THROUGH IT
    // AND ***PUSH IT*** TO THE ARRAY
    public void loadMap(){

    }

    //METHOD TO DRAW THE MAP


}
