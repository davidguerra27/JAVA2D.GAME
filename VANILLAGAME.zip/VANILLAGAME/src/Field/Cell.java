package Field;

import org.academiadecodigo.simplegraphics.pictures.Picture;

//INDIVIDUAL CELL SUPER CLASS
public class Cell {

    //THE VARIABLE THAT WILL HOLD EACH INDIVIDUAL CELL IMAGE
    public Picture picture;
    //IF THE CELL IS SOLID
    public boolean collision = false;
}
