package Field;

import org.academiadecodigo.simplegraphics.graphics.Color;
import org.academiadecodigo.simplegraphics.graphics.Rectangle;

import javax.swing.*;


public class Dialoge {
    public Rectangle dialogue;
    public Dialoge(){
         dialogue = new Rectangle(20,20,700,100);

        dialogue.setColor(Color.WHITE);

    }
    public void init(){
        this.dialogue.draw();
    }
}
