package Character;
//GIVE US ACCESS TO THE GAME?S INTERACTIVE OBJCTS PACKAGE
//import WorldObject.*;
//GIVES US ACCESS TO THE GAME SCREEN PACKAGE
//import Game.GamePanel;
//GIVES US ACCESS TO THE KEYHANDLER PACKAGE(keyboard input)
//import Game.KeyHandler;
//GIVES US ACCESS TO THE GAME SOUND PACKAGE
//import Game.Sound;
//PLAYER CHARACTER
public class Player extends Character{


}
