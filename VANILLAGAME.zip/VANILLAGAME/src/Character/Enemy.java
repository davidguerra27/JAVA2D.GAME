package Character;
//GIVES US ACCESS TO THE GAME SCREEN PACKAGE
//import Game.GamePanel;

//GIVES US ACCESS TO THE GAME SOUND PACKAGE
//import Game.Sound;

//EX MACHINA ROBOT
public class Enemy extends Character{
}
