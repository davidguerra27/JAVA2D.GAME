package character;

public class Graphics2D {

}
