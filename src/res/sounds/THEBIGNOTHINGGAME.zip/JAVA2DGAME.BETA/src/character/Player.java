package character;
import java.awt.*;
import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import WorldObject.OBJ_Sword;
import game.GamePanel;
import game.KeyHandler;
import game.Sound;

import java.awt.image.BufferedImage;


public class Player extends Character{

    KeyHandler keyH;
    Sound sound = new Sound();






    public final int screenX;
    public final int screenY;




    public Player(GamePanel gp,  KeyHandler keyH){

        super(gp);

        this.keyH = keyH;


        screenX = gp.screenWidth/2 - (gp.tileSize/2);
        screenY = gp.screenHeight/2 - (gp.tileSize/2);

        solidArea = new Rectangle();
        solidArea.x = 16;
        solidArea.y = 24;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        solidArea.width = 1;
        solidArea.height = 1;

        setDefaultValues();
        getPlayerImage();







    }



    public void setDefaultValues(){
        worldX = gp.tileSize*24;
        worldY = gp.tileSize*22;

        speed=2;
        direction = "down";

    }
    File f1 = new File("src/res/player2/player_back_1.png");
    File f2 = new File("src/res/player2/player_back_2.png");
    File f3 = new File("src/res/player2/player_front_1.png");
    File f4 = new File("src/res/player2/player_front_2.png");
    File f5 = new File("src/res/player2/player_left_1.png");
    File f6 = new File("src/res/player2/player_left_2.png");
    File f7 = new File("src/res/player2/player_right_1.png");
    File f8 = new File("src/res/player2/player_right_2.png");

    public void getPlayerImage(){
        try{
            up1 = ImageIO.read(f1);
            up2 = ImageIO.read(f2);
            down1 = ImageIO.read(f3);
            down2 = ImageIO.read(f4);
            left1 = ImageIO.read(f5);
            left2 = ImageIO.read(f6);
            right1 = ImageIO.read(f7);
            right2 = ImageIO.read(f8);



        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public void update() {
        if(keyH.upPressed == true ||keyH.downPressed == true ||
        keyH.leftPressed == true ||keyH.rightPressed == true ){
            if(keyH.upPressed == true){
                direction = "up";

            }
            else if(keyH.downPressed == true){
                direction = "down";

            }
            else if(keyH.leftPressed == true){
                direction = "left";

            }
            else if(keyH.rightPressed == true){
                direction = "right";

            }
            //CHECK TILE COLLISION
            collisionOn = false;
            gp.cChecker.checkTile(this);
            //CHECK OBJECT COLLISION
            int objIndex = gp.cChecker.checkObject(this,true);
            pickUpObject(objIndex);
            //CHECK NPC COLLISION
            int npcIndex = gp.cChecker.checkCharacter(this,gp.npc);
            interactNPC(npcIndex);

            //IF COLLISION IS FALSE,PLAYER CAN MOVE
            if(collisionOn == false){

                switch(direction){
                    case "up":worldY -=speed;break;
                    case "down":worldY +=speed;break;
                    case "left":worldX -=speed;break;
                    case "right":worldX +=speed;break;

                }
            }




            spriteCounter++;

            if(spriteCounter > 12){
                if(spriteNum == 1){
                    spriteNum = 2;
                }
                else if(spriteNum == 2){
                    spriteNum = 1;
                }

            spriteCounter = 0;
            }
        }

        
    }
    public void pickUpObject(int i){
        if(i != 999){

        }
    }
    public void interactNPC(int i){

        if(i != 999){
            System.out.println("you are hitting me!!!!");
        }
    }
    

    public void draw(Graphics2D g2){

       // g2.setColor(Color.orange);

        //g2.fillRect(x,y , gp.tileSize,gp. tileSize);
        BufferedImage image = null;

        switch(direction){

            case "up":
                if(spriteNum ==1){
                    image = up1;
                }
                if(spriteNum == 2){
                    image = up2;
                }  
                break;
            case "down":
                if(spriteNum == 1){
                  image = down1;
                }
                if(spriteNum == 2){
                    image = down2;
                }
                break;
            case "left":
                if(spriteNum == 1){
                  image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                break;
           case "right":
                if(spriteNum == 1){
                  image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }
                break;
                

        }
        g2.drawImage(image , screenX , screenY , gp.tileSize , gp.tileSize , null);
    }
}
