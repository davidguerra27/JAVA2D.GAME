package character;

import game.GamePanel;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class NCP_OldMan extends Character{

    public NCP_OldMan(GamePanel gp){
        super(gp);

        direction = "down";
        speed = 1;
        getImage();
    }
    File f1 = new File("src/res/npc/wizardFront1.png");
    File f2 = new File("src/res/npc/wizardFront1.png");
    File f3 = new File("src/res/npc/wizardBack1.png");
    File f4 = new File("src/res/npc/wizardBack2.png");
    File f5 = new File("src/res/npc/wizardLeft1.png");
    File f6 = new File("src/res/npc/wizardLeft2.png");
    File f7 = new File("src/res/npc/wizardBack1.png");
    File f8 = new File("src/res/npc/wizardBack2.png");

    public void getImage(){
        try{
            up1 = ImageIO.read(f3);
            up2 = ImageIO.read(f4);
            down1 = ImageIO.read(f1);
            down2 = ImageIO.read(f2);
            left1 = ImageIO.read(f5);
            left2 = ImageIO.read(f6);
            right1 = ImageIO.read(f7);
            right2 = ImageIO.read(f8);



        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void setAction(){

        actionLockCounter++;
        if( actionLockCounter == 120){
            Random random = new Random();
            int i = random.nextInt(100)+1;

            if( i <= 25) {
                direction = "up";
            }
            if( i > 25 && i <= 50){
                direction = "down";
            }
            if(i > 50 && i <= 75){
                direction = "left";
            }
            if( i > 75){
                direction = "right";
            }
            actionLockCounter = 0;
        }

    }

}
