
public interface Graphics2D {

}
