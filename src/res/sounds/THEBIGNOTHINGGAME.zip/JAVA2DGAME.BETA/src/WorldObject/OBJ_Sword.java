package WorldObject;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;



public class OBJ_Sword extends SuperObject{

    File sword1 = new File("src/res/objects/weapon_final1.png");

    public OBJ_Sword(){

        name = "Sword";
        try {
            image = ImageIO.read(sword1);
        }
        catch (IOException e)  {
            e.printStackTrace();
        }

    }
}
