package WorldObject;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class OBJ_Chest extends SuperObject{

    File chest1 = new File("src/res/objects/small_chest_1.png");

    public OBJ_Chest(){

        name = "Chest";
        try {
            image = ImageIO.read(chest1);
        }
        catch (IOException e)  {
            e.printStackTrace();
        }

    }
}
