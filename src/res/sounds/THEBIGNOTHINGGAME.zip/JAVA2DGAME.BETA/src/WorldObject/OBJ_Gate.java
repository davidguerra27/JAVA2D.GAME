package WorldObject;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class OBJ_Gate extends SuperObject{

    File gate1 = new File("src/res/objects/gate_up1.png");

    public OBJ_Gate(){

        name = "Gate";
        try {
            image = ImageIO.read(gate1);
        }
        catch (IOException e)  {
            e.printStackTrace();
        }
        collision = true;

    }
}
