package WorldObject;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;


public class OBJ_Ring extends SuperObject{

    File ring1 = new File("src/res/objects/ring1.png");

    public OBJ_Ring(){

        name = "Ring";
        try {
            image = ImageIO.read(ring1);
        }
        catch (IOException e)  {
            e.printStackTrace();
        }


    }
}
