package game;
import WorldObject.OBJ_Chest;
import WorldObject.OBJ_Ring;
import WorldObject.OBJ_Gate;
import WorldObject.OBJ_Sword;
import character.NCP_OldMan;

public class AssetSetter  {

    GamePanel gp;
    public AssetSetter(GamePanel gp){
        this.gp = gp;
    }
    public void setObject(){

    }
    public void setNPC(){

        gp.npc[0] = new NCP_OldMan(gp);
        gp.npc[0].worldX = gp.tileSize*26;
        gp.npc[0].worldY = gp.tileSize*22;
    }
}
