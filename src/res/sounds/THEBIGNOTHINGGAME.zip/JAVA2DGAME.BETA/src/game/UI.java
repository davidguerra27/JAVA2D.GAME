package game;



import WorldObject.OBJ_Ring;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

public class UI {
    GamePanel gp;
    Graphics2D g2;
    Font helvetica_35;

    public boolean messageOn = false;
    public String message = "";
    int messageCounter = 0;


    public UI(GamePanel gp){
        this.gp = gp;
        helvetica_35 = new Font("HELVETICA",Font.BOLD,80);


    }
    public void showMessage(String text){
        message = text;
        messageOn = true;

    }
    public void draw(Graphics2D g2){
            this.g2 =g2;

            g2.setFont(helvetica_35);
            g2.setColor(Color.MAGENTA);
            if( gp.gameState == gp.playState){

            }
            else if( gp.gameState == gp.pauseState ){
                drawPauseScreen();
            }
    }
    public void drawPauseScreen() {
        String text = "PAUSE";
        int x = getXForCenteredText(text);

        int y = gp.screenHeight / 2;
        RoundRectangle2D menu = new RoundRectangle2D() {


            @Override
            public double getArcWidth() {
                return 100;
            }

            @Override
            public double getArcHeight() {
                return 200;
            }

            @Override
            public void setRoundRect(double x, double y, double w, double h, double arcWidth, double arcHeight) {

            }


            @Override
            public double getX() {
                return 220;
            }

            @Override
            public double getY() {
                return 200;
            }

            @Override
            public double getWidth() {
                return 500;
            }

            @Override
            public double getHeight() {
                return 800;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public Rectangle2D getBounds2D() {
                return null;
            }

        };


        g2.drawRoundRect((int) menu.getX(), (int) menu.getY(), (int) menu.getWidth(), (int) menu.getArcHeight(), (int) menu.getArcWidth(), (int) menu.getArcHeight());

        g2.drawString(text , x , y);
    }
    public int getXForCenteredText(String text){
        int length = (int)g2.getFontMetrics().getStringBounds(text , g2).getWidth();
        int x = gp.screenWidth/2 - length/2;
        return x;
    }

}
